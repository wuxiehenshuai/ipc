#pragma once
#pragma warning(disable:4996)
#undef UNICODE
#undef _UNICODE
#include<stdio.h>
#include<easyx.h>
#include<graphics.h>
#define WIN_WIDTH 640
#define WIN_HEIGHT 480
#define MAX_SNAKE 100
void reverse();
IMAGE img[1000];
enum DIR
{
	UP,
	DOWN,
	LEFT,
	RIGHT,
};
struct Food_tlg
{
	POINT fd;
	int flag;


}food;
struct Snake_tlg
{
	int num;
	int dir;//�ߵķ���
	int score;//�ƶ��ٶ�
	int size=20;
	POINT coor[MAX_SNAKE];
}snake;
void GameInit()
{
	srand(GetTickCount());
	snake.num = 3;
	snake.dir = RIGHT;
	snake.score = 0;
	snake.coor[2].x = 0;
	snake.coor[2].y = 0;
	snake.coor[1].x = 20;
	snake.coor[1].y = 0;
	snake.coor[0].x = 40;
	snake.coor[0].y = 0;
	food.fd.x = rand() % (WIN_WIDTH/20)*20;
	food.fd.y = rand() % (WIN_HEIGHT/20)*20;
	food.flag = 1;

}
void GameDraw()
{
	setbkcolor(BLACK);
	cleardevice();
	setfillcolor(YELLOW);
	loadimage(img + 0, "./snakeHeadright.png", 20, 20);
	reverse();
	loadimage(img + 999, "./food.png", 20, 20);
	for (int i = 1; i < snake.num; i++)
	{
		loadimage(img + i, "./snakeBody.png", 20, 20);
	}
	for (int i = 0; i < snake.num; i++)
	{
		putimage(snake.coor[i].x, snake.coor[i].y, img + i);
		printf("%d %d\n", snake.coor[i].x, snake.coor[i].y);
	}
	if (food.flag == 1)
	{ 
		loadimage(img+999, "./food.png", 20, 20);
		putimage(food.fd.x, food.fd.y, img+999);
	}
	char temp[20] = "";
	sprintf(temp, "������%d", snake.score);
	outtextxy(20, 20, temp);
	setbkmode(TRANSPARENT);
}
void Snakemove()
{
	for (int i = snake.num - 1; i > 0; i--)
	{
		snake.coor[i].x = snake.coor[i - 1].x;
		snake.coor[i].y = snake.coor[i - 1].y;
		
     }    
	switch (snake.dir)
	{
	case UP:
		snake.coor[0].y -= 20;
		
		if (snake.coor[0].y +20<= 0)
		{  
			snake.coor[0].y = WIN_HEIGHT;
		}
			break;
	case DOWN:
		snake.coor[0].y += 20;
		
		if (snake.coor[0].y - 20 >= WIN_HEIGHT)
		{
			snake.coor[0].y = 0;
		}
		break;
	case LEFT:
		snake.coor[0].x -= 20;
		
		if (snake.coor[0].x + 20 <= 0)
		{
			snake.coor[0].x= WIN_WIDTH;
		}
		break;
	case RIGHT:
		snake.coor[0].x += 20;
		
		if (snake.coor[0].x- 20 >= WIN_WIDTH)
		{
			snake.coor[0].x = 0;
		}
		break;
	default:
		break;
	}


}
void KeyControl()
{
	if (GetAsyncKeyState(VK_UP)&&snake.dir!=DOWN)
	{
		
		snake.dir = UP;

	}
	if(GetAsyncKeyState(VK_DOWN)&&snake.dir!=UP)
	{
		
		snake.dir = DOWN;
	}
	if (GetAsyncKeyState(VK_LEFT)&&snake.dir!=RIGHT)
	{
		
		snake.dir = LEFT;

	}
	if (GetAsyncKeyState(VK_RIGHT)&&snake.dir!=LEFT)
	{
		
		snake.dir = RIGHT;

	}
}
void EatFood()
{
	if (snake.coor[0].x == food.fd.x && snake.coor[0].y == food.fd.y && food.flag == 1)
	{
		snake.num++;
		snake.score += 20;
		food.flag = 0;
	}
	if (food.flag == 0)
	{
		food.fd.x = rand() % (WIN_WIDTH / 20) * 20;
		food.fd.y = rand() % (WIN_HEIGHT / 20) * 20;
		food.flag = 1;
	}
}
void reverse()
{
	if (snake.dir == UP)
	{
		loadimage(img + 0, "./snakeHeadup.png", 20, 20);
	}
	else if (snake.dir == DOWN)
	{
		loadimage(img + 0, "./snakeHeaddown.png", 20, 20);
	}
	else if (snake.dir == LEFT)
	{
		loadimage(img + 0, "./snakeHeadleft.png", 20, 20);
	}
	else if (snake.dir = RIGHT)
	{
		loadimage(img + 0, "./snakeHeadright.png", 20, 20);
	}
}
int main()
{
	initgraph(WIN_WIDTH,WIN_HEIGHT , EX_SHOWCONSOLE);
	GameInit();
	DWORD t1, t2;
	t1 = t2 = GetTickCount();
	BeginBatchDraw();
	while (1)
	{
		
		if (t2 - t1 > 100)
		{
			Snakemove();
			t1 = t2;
		}t2 = GetTickCount();
		
		GameDraw();
		EatFood();
		KeyControl();
		Sleep(50);
		FlushBatchDraw();
	}
	getchar();
	closegraph();
	
}